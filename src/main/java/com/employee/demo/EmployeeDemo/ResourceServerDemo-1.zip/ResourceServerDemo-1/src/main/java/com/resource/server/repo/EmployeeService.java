package com.resource.server.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.resource.server.dto.Employee;

@Repository
public interface EmployeeService extends CrudRepository<Employee, Long>{
  Employee findByNameAndAddress(String name,String address);
}
