package com.resource.server.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.resource.server.dto.Employee;
import com.resource.server.repo.EmployeeService;


@RestController
@RequestMapping(path = "/api")
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/getEmployees")
    public List<Employee> getAllEmployees() {
        return (List<Employee>) employeeService.findAll();
    }
	
	 @PostMapping("/addEmployees")
	    public Employee createEmployee(@Valid @RequestBody Employee employee) {
	        return employeeService.save(employee);
	    }
	 @PostMapping("/delEmployees")
	    public void deleteEmployee(@Valid @RequestBody Employee employee) {
	         employeeService.delete(employee);
	    }
}