import { Component, OnInit } from '@angular/core';
import {Employee} from '../employee';
import {empList} from '../mock-employee';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
emp: Employee = {
      id: 1,
      name: 'Bhushan',
      address:'Indore'
    };
  constructor() { }
  title="First Anguler Project"
  ngOnInit() {
   // empList=empList;
  }


}
