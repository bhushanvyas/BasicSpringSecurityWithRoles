import {Employee} from './employee';

export const empList: Employee[]=[
{id:1,name:'BHushan', address:'Indore'},
{id:2,name:'Arvind', address:'Ajmer'},
{id:3,name:'Rohit', address:'Mandsaur'},
{id:4,name:'Krishna', address:'Ratlam'},
{id:5,name:'Avikal', address:'Ujjain'}
];